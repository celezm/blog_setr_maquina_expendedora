#pragma once
#include <Arduino.h>
#include <LiquidCrystal.h>

extern LiquidCrystal lcd;
void WriteLine(byte row, const char *text);
